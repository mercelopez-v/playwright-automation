import { test, expect } from '@playwright/test';
import { CommonPage } from '../pages/CommonPage';
import { LoginPage } from '../pages/LoginPage';
import testData from '../fixtures/data.json';

const elements = {

  // Inventory / Home
  title: '.title',
  addToCartBackpack: '[data-test="add-to-cart-sauce-labs-backpack"]',
  shoppingCartLink: '.shopping_cart_link',

  // Checkout
  checkoutButton: '[data-test="checkout"]',
  firstNameInput: '[data-test="firstName"]',
  lastNameInput: '[data-test="lastName"]',
  postalCodeInput: '[data-test="postalCode"]',
  continueButton: '[data-test="continue"]',
  finishButton: '[data-test="finish"]',
  completeHeader: '.complete-header'
};

test('Test 3: Flujo completo de compra (SauceDemo)', async ({ page }) => {
  const data = testData.sauceDemo;
  const login = new LoginPage(page);
  const common = new CommonPage(page);

  // 1. Navegar a la plataforma
  await common.navigateTo(data.url)

  // 2. Iniciar sesión usando credenciales del data.json
  await login.login(data.user,data.password)

  // 3. Validar que ingresó al catálogo
  await common.assertText(elements.title,data.productsTitle)

  // 4. Agregar producto al carrito y continuar al checkout
  await page.click(elements.addToCartBackpack)
  await page.click(elements.shoppingCartLink);
  await page.click(elements.checkoutButton);

  // 5. Completar datos del cliente desde data.json
  await page.fill(elements.firstNameInput, data.customer.firstName);
  await page.fill(elements.lastNameInput, data.customer.lastName);
  await page.fill(elements.postalCodeInput, data.customer.postalCode);
  await page.click(elements.continueButton);

  // 6. Confirmar la compra y validar mensaje final
  await page.click(elements.finishButton);
  await common.assertText(elements.completeHeader,data.successOrderMessage)
});